package com.niu.myapp.actcomwifrag.util;

/**
 * 函数异常
 * Created by niuxiaowei on 2016/1/25.
 */
public class FunctionException extends Exception{
    public FunctionException(String msg){
        super();
    }
}
